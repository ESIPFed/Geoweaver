import subprocess
import sys

try:
    import pandas as pd
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", 'pandas'])
finally:
    import pandas as pd

emissions = pd.read_csv("~/tropomi_epa_kvps_NO2_2019_56.csv")
print("==================>")
print("Describe data")
print(emissions.describe())
print("==================>")
print("==================>")
print("Check shape of data")
print(emissions.shape)
print("==================>")
print("==================>")
print("Check available columns")
print(emissions.columns)
print("==================>")
print("==================>")
print("Any NULL values in features?")
print(emissions.isnull().sum())
print("==================>")
