import subprocess
import sys

try:
    import pandas as pd
except ImportError:
	subprocess.check_call([sys.executable, "-m", "pip", "install", 'pandas'])
finally:
    import pandas as pd


emissions = pd.read_csv('https://raw.githubusercontent.com/ZihengSun/EmissionAI/main/data/tropomi_epa_kvps_NO2_2019_56.csv' , parse_dates=["Date"])
print(emissions)
emissions.to_csv("~/tropomi_epa_kvps_NO2_2019_56.csv")
